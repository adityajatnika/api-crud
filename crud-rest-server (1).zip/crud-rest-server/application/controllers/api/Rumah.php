<?php
defined('BASEPATH') or exit('No direct script access allowed');

use chriskacerguis\RestServer\RestController;

class Rumah extends RestController
{

    public function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->model('Rumah_model', 'rumah');
        $this->load->model('Users_model', 'user');
    }

    public function index_get()
    {

        $id = $this->get('id');
        $rumah = $this->rumah->getRumah($id);

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id user'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($rumah) {
                $this->response([
                    'status' => true,
                    'listKeluarga' => $rumah,
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id user tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_delete()
    {
        $id = $this->delete('id');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($this->rumah->deleteRumah($id) > 0) {
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'dihapus'
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_post()
    {
        $data = [
            'id_user' => $this->post('id_user'),
            'jenis_bangunan' => $this->post('jenis_bangunan'),
            'status_milik' => $this->post('status_milik'),
            'harga_sewa' => $this->post('harga_sewa'),
            'lama_tinggal' => $this->post('lama_tinggal'),
            'konsumsi_rt' => $this->post('konsumsi_rt'),
            'foto_rumah' => $this->post('foto_rumah'),
        ];

        if ($user = $this->user->getUser($this->post('id_user'))) {
            if ($this->rumah->createRumah($data) > 0) {
                $this->response([
                    'status' => true,
                    'message' => 'rumah ditambahkan'
                ], RestController::HTTP_CREATED);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'input data tidak valid'
                ], RestController::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'status' => false,
                'message' => 'id user tidak ditemukan'
            ], 404);
        }
    }

    public function index_put()
    {

        $id = $this->put('id');
        $data = [
            'jenis_bangunan' => $this->put('jenis_bangunan'),
            'status_milik' => $this->put('status_milik'),
            'harga_sewa' => $this->put('harga_sewa'),
            'lama_tinggal' => $this->put('lama_tinggal'),
            'konsumsi_rt' => $this->put('konsumsi_rt'),
            'foto_rumah' => $this->put('foto_rumah'),
        ];
        if ($this->rumah->updateRumah($data, $id) > 0) {
            $this->response([
                'status' => true,
                'message' => 'rumah diupdate'
            ], RestController::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'gagal update data'
            ], 404);
        }
    }
}
