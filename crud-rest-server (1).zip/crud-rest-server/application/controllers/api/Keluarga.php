<?php
defined('BASEPATH') or exit('No direct script access allowed');

use chriskacerguis\RestServer\RestController;

class Keluarga extends RestController
{

    public function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->model('Keluarga_model', 'keluarga');
        $this->load->model('Users_model', 'user');
    }

    public function index_get()
    {

        $id = $this->get('id');
        $keluarga = $this->keluarga->getKeluarga($id);

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id user'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($keluarga) {
                $this->response([
                    'status' => true,
                    'listKeluarga' => $keluarga,
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id user tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_delete()
    {
        $id = $this->delete('id');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($this->keluarga->deleteKeluarga($id) > 0) {
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'dihapus'
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_post()
    {
        $data = [
            'id_user' => $this->post('id_user'),
            'nama' => $this->post('nama'),
            'status_keluarga' => $this->post('status_keluarga'),
            'jenis_kelamin' => $this->post('jenis_kelamin'),
            'umur' => $this->post('umur'),
            'pendidikan' => $this->post('pendidikan'),
            'pekerjaan' => $this->post('pekerjaan'),
            'pendapatan' => $this->post('pendapatan'),
        ];

        if ($user = $this->user->getUser($this->post('id_user'))) {
            if ($this->keluarga->createKeluarga($data) > 0) {
                $this->response([
                    'status' => true,
                    'message' => 'keluarga ditambahkan'
                ], RestController::HTTP_CREATED);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'input data tidak valid'
                ], RestController::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'status' => false,
                'message' => 'id user tidak ditemukan'
            ], 404);
        }
    }

    public function index_put()
    {

        $id = $this->put('id');
        $data = [
            'nama' => $this->put('nama'),
            'status_keluarga' => $this->put('status_keluarga'),
            'jenis_kelamin' => $this->put('jenis_kelamin'),
            'umur' => $this->put('umur'),
            'pendidikan' => $this->put('pendidikan'),
            'pekerjaan' => $this->put('pekerjaan'),
            'pendapatan' => $this->put('pendapatan'),
        ];
        if ($this->keluarga->updateKeluarga($data, $id) > 0) {
            $this->response([
                'status' => true,
                'message' => 'keluarga diupdate'
            ], RestController::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'gagal update data'
            ], 404);
        }
    }
}
