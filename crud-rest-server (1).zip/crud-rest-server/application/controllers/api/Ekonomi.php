<?php
defined('BASEPATH') or exit('No direct script access allowed');

use chriskacerguis\RestServer\RestController;

class Ekonomi extends RestController
{

    public function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->model('Ekonomi_model', 'ekonomi');
        $this->load->model('Users_model', 'user');
    }

    public function index_get()
    {

        $id = $this->get('id');
        $ekonomi = $this->ekonomi->getEkonomi($id);

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id user'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($ekonomi) {
                $this->response([
                    'status' => true,
                    'listKeluarga' => $ekonomi,
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id user tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_delete()
    {
        $id = $this->delete('id');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($this->ekonomi->deleteEkonomi($id) > 0) {
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'dihapus'
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_post()
    {
        $data = [
            'id_user' => $this->post('id_user'),
            'total_pendapatan' => $this->post('total_pendapatan'),
            'pendapatan_usaha' => $this->post('pendapatan_usaha'),
            'pendapatan_kiriman' => $this->post('pendapatan_kiriman'),
            'subsidi_pemerintah' => $this->post('subsidi_pemerintah'),
        ];

        if ($user = $this->user->getUser($this->post('id_user'))) {
            if ($this->ekonomi->createEkonomi($data) > 0) {
                $this->response([
                    'status' => true,
                    'message' => 'ekonomi ditambahkan'
                ], RestController::HTTP_CREATED);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'input data tidak valid'
                ], RestController::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'status' => false,
                'message' => 'id user tidak ditemukan'
            ], 404);
        }
    }

    public function index_put()
    {

        $id = $this->put('id');
        $data = [
            'total_pendapatan' => $this->put('total_pendapatan'),
            'pendapatan_usaha' => $this->put('pendapatan_usaha'),
            'pendapatan_kiriman' => $this->put('pendapatan_kiriman'),
            'subsidi_pemerintah' => $this->put('subsidi_pemerintah'),
        ];
        if ($this->ekonomi->updateEkonomi($data, $id) > 0) {
            $this->response([
                'status' => true,
                'message' => 'ekonomi diupdate'
            ], RestController::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'gagal update data'
            ], 404);
        }
    }
}
