<?php
defined('BASEPATH') or exit('No direct script access allowed');

use chriskacerguis\RestServer\RestController;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class User extends RestController
{

    public function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->model('Users_model', 'user');
        $this->load->library('Authorization_Token');
    }

    public function index_get()
    {

        $key = 'example_key';

        $id = $this->get('id');
        if ($id === null) {
            $user = $this->user->getUser();
        } else {
            $user = $this->user->getUser($id);
        }
        // JWT::$leeway = 3600;
        // $jwt = JWT::encode($user, $key, 'HS256');

        if ($user) {
            $this->response([
                'status' => true,
                'listUser' => $user
            ], RestController::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], RestController::HTTP_NOT_FOUND);
        }
    }

    public function index_delete()
    {
        $id = $this->delete('id');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($this->user->deleteUser($id) > 0) {
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'dihapus'
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_post()
    {
        $data = [
            'nama' => $this->post('nama'),
            'password' => $this->post('password'),
            'email' => $this->post('email'),
            'jenis_kelamin' => $this->post('jenis_kelamin'),
            'status_keluarga' => $this->post('status_keluarga'),
            'pendidikan' => $this->post('pendidikan'),
            'pekerjaan' => $this->post('pekerjaan'),
        ];

        if ($this->user->createUser($data)) {
            if ($this->user->createUser($data) > 0) {
                $this->response([
                    'status' => true,
                    'message' => 'user ditambahkan'
                ], RestController::HTTP_CREATED);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'input data tidak valid'
                ], 404);
            }
        } else {
            $this->response([
                'status' => false,
                'message' => 'input data tidak sesuai'
            ], RestController::HTTP_BAD_REQUEST);
        }
    }

    public function index_put()
    {

        $id = $this->put('id');
        $data = [
            'nama' => $this->put('nama'),
            'password' => $this->put('password'),
            'email' => $this->put('email'),
            'jenis_kelamin' => $this->put('jenis_kelamin'),
            'status_keluarga' => $this->put('status_keluarga'),
            'pendidikan' => $this->put('pendidikan'),
            'pekerjaan' => $this->put('pekerjaan'),
        ];
        if ($this->user->updateUser($data, $id) > 0) {
            $this->response([
                'status' => true,
                'message' => 'user diupdate'
            ], RestController::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'gagal update data'
            ], 404);
        }
    }



    public function login_get()
    {
        // $key = 'example_key';
        $id = $this->get('id');
        if ($id === null) {
            $user = $this->user->getUser();
        } else {
            $user = $this->user->getUser($id);
        }
        $token = $this->authorization_token->generateToken($user);
        $final['token'] = $token;
        $final['status'] = 'true';
        $this->response($final);
    }
    public function tes_get()
    {
        $headers = $this->input->request_headers();
        $decodedToken = $this->authorization_token->validateToken($headers['Authorization']);
        $this->response([$decodedToken]);
    }

    public function fetch_get()
    {


        $headers = $this->input->request_headers();

        // $key = 'example_key';
        // $headers = apache_request_headers()['Authorization'];
        // $decoded = JWT::decode($headers, new Key($key, 'HS256'));
        $decodedToken = $this->authorization_token->validateToken($headers['Authorization']);
        $this->response([$decodedToken]);
        if ($decodedToken) {
            $this->response($decodedToken);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], RestController::HTTP_NOT_FOUND);
        }
    }
}
