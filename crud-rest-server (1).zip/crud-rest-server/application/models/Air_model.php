<?php

class Air_model extends CI_Model
{
    public function getAir($id_user)
    {
        return $this->db->get_where('sarana_air', ['id_user' => $id_user])->result_array();
    }

    public function deleteAir($id)
    {
        $this->db->delete('sarana_air', ['id' => $id]);
        return $this->db->affected_rows();
    }

    public function createAir($data)
    {
        $this->db->insert('sarana_air', $data);
        return $this->db->affected_rows();
    }

    public function updateAir($data, $id)
    {
        $this->db->update('sarana_air', $data, ['id_user' => $id]);
        return $this->db->affected_rows();
    }
}
