<?php

class Lokasi_model extends CI_Model
{
    public function getLokasi($id_user)
    {
        return $this->db->get_where('lokasi', ['id_user' => $id_user])->result_array();
    }

    public function deleteLokasi($id)
    {
        $this->db->delete('lokasi', ['id' => $id]);
        return $this->db->affected_rows();
    }

    public function createLokasi($data)
    {
        $this->db->insert('lokasi', $data);
        return $this->db->affected_rows();
    }

    public function updateLokasi($data, $id)
    {
        $this->db->update('lokasi', $data, ['id_user' => $id]);
        return $this->db->affected_rows();
    }
}
