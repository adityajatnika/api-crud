<?php

class Rumah_model extends CI_Model
{
    public function getRumah($id_user)
    {
        return $this->db->get_where('rumah', ['id_user' => $id_user])->result_array();
    }

    public function deleteRumah($id)
    {
        $this->db->delete('rumah', ['id' => $id]);
        return $this->db->affected_rows();
    }

    public function createRumah($data)
    {
        $this->db->insert('rumah', $data);
        return $this->db->affected_rows();
    }


    public function updateRumah($data, $id)
    {
        $this->db->update('rumah', $data, ['id_user' => $id]);
        return $this->db->affected_rows();
    }
}
