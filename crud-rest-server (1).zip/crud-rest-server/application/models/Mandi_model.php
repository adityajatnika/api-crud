<?php

class Mandi_model extends CI_Model
{
    public function getMandi($id_user)
    {
        return $this->db->get_where('sarana_mandi', ['id_user' => $id_user])->result_array();
    }

    public function delete($id)
    {
        $this->db->delete('sarana_mandi', ['id' => $id]);
        return $this->db->affected_rows();
    }

    public function createMandi($data)
    {
        $this->db->insert('sarana_mandi', $data);
        return $this->db->affected_rows();
    }

    public function updateMandi($data, $id)
    {
        $this->db->update('sarana_mandi', $data, ['id_user' => $id]);
        return $this->db->affected_rows();
    }
}
