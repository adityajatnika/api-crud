<?php

class Users_model extends CI_Model
{
    public function getUser($id = null)
    {
        if ($id === null) {
            return $this->db->get('user');
        } else {
            return $this->db->get('user', ['id' => $id]);
        }
    }

    public function deleteUser($id)
    {
        $this->db->delete('user', ['id' => $id]);
        return $this->db->affected_rows();
    }

    public function createUser($data)
    {
        $this->db->insert('user', $data);
        return $this->db->affected_rows();
    }


    public function updateUser($data, $id)
    {
        $this->db->update('user', $data, ['id' => $id]);
        return $this->db->affected_rows();
    }
}
