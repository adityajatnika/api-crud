<?php

class Ekonomi_model extends CI_Model
{
    public function getEkonomi($id_user)
    {
        return $this->db->get_where('ekonomi', ['id_user' => $id_user])->result_array();
    }

    public function deleteEkonomi($id)
    {
        $this->db->delete('ekonomi', ['id' => $id]);
        return $this->db->affected_rows();
    }

    public function createEkonomi($data)
    {
        $this->db->insert('ekonomi', $data);
        return $this->db->affected_rows();
    }

    public function updateEkonomi($data, $id)
    {
        $this->db->update('ekonomi', $data, ['id_user' => $id]);
        return $this->db->affected_rows();
    }
}
