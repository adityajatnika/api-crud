<?php
defined('BASEPATH') or exit('No direct script access allowed');

use chriskacerguis\RestServer\RestController;

class Mandi extends RestController
{

    public function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->model('Mandi_model', 'mandi');
        $this->load->model('Users_model', 'user');
    }

    public function index_get()
    {

        $id = $this->get('id');
        $mandi = $this->mandi->getMandi($id);

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id user'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($mandi) {
                $this->response([
                    'status' => true,
                    'listKeluarga' => $mandi,
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id user tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_delete()
    {
        $id = $this->delete('id');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($this->mandi->deleteMandi($id) > 0) {
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'dihapus'
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_post()
    {
        $data = [
            'id_user' => $this->post('id_user'),
            'tempat_mandi' => $this->post('tempat_mandi'),
            'saluran_grey_water' => $this->post('saluran_grey_water'),
            'foto_saluran_grey' => $this->post('foto_saluran_grey'),
            'tempat_bab' => $this->post('tempat_bab'),
            'jamban' => $this->post('jamban'),
            'saluran_black_water' => $this->post('saluran_black_water'),
            'foto_saluran_black' => $this->post('foto_saluran_black'),
            'jenis_tangki_septik' => $this->post('jenis_tangki_septik'),
            'foto_tangki' => $this->post('foto_tangki'),
            'letak_tangki_septik' => $this->post('letak_tangki_septik'),
            'usia_tangki_septik' => $this->post('usia_tangki_septik'),
            'pengosongan_tangki_septik' => $this->post('pengosongan_tangki_septik'),
            'akses_sedot' => $this->post('akses_sedot'),
            'foto_manhole' => $this->post('foto_manhole'),
            'cara_kosong' => $this->post('cara_kosong'),
            'jarak_tangki_ke_sumur' => $this->post('jarak_tangki_ke_sumur'),
            'lubang_vent' => $this->post('lubang_vent'),
            'foto_vent' => $this->post('foto_vent'),
        ];

        if ($user = $this->user->getUser($this->post('id_user'))) {
            if ($this->mandi->createMandi($data) > 0) {
                $this->response([
                    'status' => true,
                    'message' => 'mandi ditambahkan'
                ], RestController::HTTP_CREATED);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'input data tidak valid'
                ], RestController::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'status' => false,
                'message' => 'id user tidak ditemukan'
            ], 404);
        }
    }

    public function index_put()
    {

        $id = $this->put('id');
        $data = [
            'tempat_mandi' => $this->put('tempat_mandi'),
            'saluran_grey_water' => $this->put('saluran_grey_water'),
            'foto_saluran_grey' => $this->put('foto_saluran_grey'),
            'tempat_bab' => $this->put('tempat_bab'),
            'jamban' => $this->put('jamban'),
            'saluran_black_water' => $this->put('saluran_black_water'),
            'foto_saluran_black' => $this->put('foto_saluran_black'),
            'jenis_tangki_septik' => $this->put('jenis_tangki_septik'),
            'foto_tangki' => $this->put('foto_tangki'),
            'letak_tangki_septik' => $this->put('letak_tangki_septik'),
            'usia_tangki_septik' => $this->put('usia_tangki_septik'),
            'pengosongan_tangki_septik' => $this->put('pengosongan_tangki_septik'),
            'akses_sedot' => $this->put('akses_sedot'),
            'foto_manhole' => $this->put('foto_manhole'),
            'cara_kosong' => $this->put('cara_kosong'),
            'jarak_tangki_ke_sumur' => $this->put('jarak_tangki_ke_sumur'),
            'lubang_vent' => $this->put('lubang_vent'),
            'foto_vent' => $this->put('foto_vent'),
        ];
        if ($this->mandi->updateMandi($data, $id) > 0) {
            $this->response([
                'status' => true,
                'message' => 'mandi diupdate'
            ], RestController::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'gagal update data'
            ], 404);
        }
    }
}
