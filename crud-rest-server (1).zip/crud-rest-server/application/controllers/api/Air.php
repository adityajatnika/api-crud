<?php
defined('BASEPATH') or exit('No direct script access allowed');

use chriskacerguis\RestServer\RestController;

class Air extends RestController
{

    public function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->model('Air_model', 'air');
        $this->load->model('Users_model', 'user');
    }

    public function index_get()
    {

        $id = $this->get('id');
        $air = $this->air->getAir($id);

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id user'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($air) {
                $this->response([
                    'status' => true,
                    'listKeluarga' => $air,
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id user tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_delete()
    {
        $id = $this->delete('id');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($this->air->deleteAir($id) > 0) {
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'dihapus'
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_post()
    {
        $data = [
            'id_user' => $this->post('id_user'),
            'air_minum' => $this->post('air_minum'),
            'air_masak' => $this->post('air_masak'),
            'sambungan_pam' => $this->post('sambungan_pam'),
            'pam_macet' => $this->post('pam_macet'),
            'kualitas_pam' => $this->post('kualitas_pam'),
            'kualitas_sumur' => $this->post('kualitas_sumur'),
            'sumur_kering' => $this->post('sumur_kering'),
            'lama_kering' => $this->post('lama_kering'),
            'konsumsi_air' => $this->post('konsumsi_air'),

        ];

        if ($user = $this->user->getUser($this->post('id_user'))) {
            if ($this->air->createAir($data) > 0) {
                $this->response([
                    'status' => true,
                    'message' => 'air ditambahkan'
                ], RestController::HTTP_CREATED);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'input data tidak valid'
                ], RestController::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'status' => false,
                'message' => 'id user tidak ditemukan'
            ], 404);
        }
    }

    public function index_put()
    {

        $id = $this->put('id');
        $data = [
            'air_minum' => $this->put('air_minum'),
            'air_masak' => $this->put('air_masak'),
            'sambungan_pam' => $this->put('sambungan_pam'),
            'pam_macet' => $this->put('pam_macet'),
            'kualitas_pam' => $this->put('kualitas_pam'),
            'kualitas_sumur' => $this->put('kualitas_sumur'),
            'sumur_kering' => $this->put('sumur_kering'),
            'lama_kering' => $this->put('lama_kering'),
            'konsumsi_air' => $this->put('konsumsi_air'),
        ];
        if ($this->air->updateAir($data, $id) > 0) {
            $this->response([
                'status' => true,
                'message' => 'air diupdate'
            ], RestController::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'gagal update data'
            ], 404);
        }
    }
}
