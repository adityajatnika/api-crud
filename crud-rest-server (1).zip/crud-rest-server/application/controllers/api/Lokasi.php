<?php
defined('BASEPATH') or exit('No direct script access allowed');

use chriskacerguis\RestServer\RestController;

class Lokasi extends RestController
{

    public function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->model('Lokasi_model', 'lokasi');
        $this->load->model('Users_model', 'user');
    }

    public function index_get()
    {

        $id = $this->get('id');
        $lokasi = $this->lokasi->getLokasi($id);

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id user'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($lokasi) {
                $this->response([
                    'status' => true,
                    'listKeluarga' => $lokasi,
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id user tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_delete()
    {
        $id = $this->delete('id');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'harus cantumkan id'
            ], RestController::HTTP_BAD_REQUEST);
        } else {
            if ($this->lokasi->deleteLokasi($id) > 0) {
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'dihapus'
                ], RestController::HTTP_OK);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id tidak ditemukan'
                ], 404);
            }
        }
    }

    public function index_post()
    {
        $data = [
            'id_user' => $this->post('id_user'),
            'kota_kab' => $this->post('kota_kab'),
            'kecamatan' => $this->post('kecamatan'),
            'kelurahan_desa' => $this->post('kelurahan_desa'),
            'rt' => $this->post('rt'),
            'rw' => $this->post('rw'),
            'lat' => $this->post('lat'),
            'lon' => $this->post('lon'),

        ];

        if ($user = $this->user->getUser($this->post('id_user'))) {
            if ($this->lokasi->createLokasi($data) > 0) {
                $this->response([
                    'status' => true,
                    'message' => 'lokasi ditambahkan'
                ], RestController::HTTP_CREATED);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'input data tidak valid'
                ], RestController::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'status' => false,
                'message' => 'id user tidak ditemukan'
            ], 404);
        }
    }

    public function index_put()
    {

        $id = $this->put('id');
        $data = [
            'kota_kab' => $this->put('kota_kab'),
            'kecamatan' => $this->put('kecamatan'),
            'kelurahan_desa' => $this->put('kelurahan_desa'),
            'rt' => $this->put('rt'),
            'rw' => $this->put('rw'),
            'lat' => $this->put('lat'),
            'lon' => $this->put('lon'),
        ];
        if ($this->lokasi->updateLokasi($data, $id) > 0) {
            $this->response([
                'status' => true,
                'message' => 'lokasi diupdate'
            ], RestController::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'gagal update data'
            ], 404);
        }
    }
}
